<?php

namespace App\Http\Controllers;

use App\Models\Tag;
use Illuminate\Http\Request;

class MainController extends Controller
{
    public function index()
    {
        // Создайте запрос на вывод всех пользователей из таблицы users
        $tag = new Tag();
        $tag->title = 'hello world';
        $tag->save();
        return view('admin.index'); // Выведите всех пользователей в таблицу (все поля)
   
    }
}
        //Сделайте так чтобы только авторизованный пользователь мог видеть все посты
        //(скрыть от гостя)