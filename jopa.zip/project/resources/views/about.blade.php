@extends('layouts.layout')

@section('title')
  @parent - {{ $title }}
@endsection

@section('content')

    <div class="container mt-5">
        <h1>About Page</h1>
    </div>

@endsection