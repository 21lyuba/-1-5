

<?php $__env->startSection('title'); ?>
  <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> - <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container mt-5">
        <h1>About Page</h1>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\isp222\resources\views/about.blade.php ENDPATH**/ ?>